package dev.pulse.trigger.gui;

public class ClickGUI {
    public void open() {
    }
}