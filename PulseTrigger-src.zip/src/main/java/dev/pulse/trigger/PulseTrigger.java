package dev.pulse.trigger;

import net.fabricmc.api.ClientModInitializer;

public class PulseTrigger implements ClientModInitializer {
    public static final String MOD_ID = "pulsetrigger";

    @Override
    public void onInitializeClient() {
        System.out.println("[PulseTrigger] Loaded");
    }
}