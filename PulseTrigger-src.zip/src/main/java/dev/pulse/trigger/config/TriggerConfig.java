package dev.pulse.trigger.config;

public class TriggerConfig {
    public boolean enabled = true;
    public double hitChance = 0.98;
    public boolean requireClick = true;
}