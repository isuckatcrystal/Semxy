package dev.pulse.trigger.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.EntityHitResult;

public class TriggerBot {

    private final MinecraftClient mc = MinecraftClient.getInstance();

    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (!mc.options.attackKey.isPressed()) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;

        Entity target = hit.getEntity();
        if (!target.isAlive()) return;
        if (mc.player.getAttackCooldownProgress(0) < 0.9f) return;

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(mc.player.getActiveHand());
    }
}